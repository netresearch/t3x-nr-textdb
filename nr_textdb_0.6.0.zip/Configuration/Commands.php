<?php
return [
    'nr_textdb:import' => [
        'class' => \Netresearch\NrTextdb\Command\ImportCommand::class
    ],
];